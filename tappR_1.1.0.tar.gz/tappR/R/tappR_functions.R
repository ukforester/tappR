# Format data and perform checks
format.data <- function(Data){

  # Initial data checks
  if(!all(colnames(Data) %in% c("Sp","DBH","Freq","CC"))) stop("colnames misspecified")
  if(all(c("DBH","CC") %in% colnames(Data))) stop("DBH and CC present in Data; include either DBH or CC")

  if(anyNA(Data)) stop("NA present in data")
  if(any(!Data$Sp %in% c("RM","rm","SM","sm"))) stop("Sp must be either 'rm' or 'sm'")
  if(any(!Data$CC %in% c("overtopped","Overtopped","intermediate","Intermediate",
                         "codominant","Codominant","dominant","Dominant"))){
    stop("CC must be %in% c('overtopped','Overtopped','intermediate','Intermediate',
                         'codominant','Codominant','dominant','Dominant')")}

  # Convert all characters to lowercase
  Data$Sp <- tolower(Data$Sp)
  if("CC" %in% colnames(Data)) Data$CC <- tolower(Data$CC)
  return(Data)
}

# DBH Routine
est.dbh <- function(Data, taps2, taps3, taps2.eff, taps3.eff){

  # Calculate per-tap sap volume
  Data$Sap.tap <- with(Data,
                       ifelse(Sp == "rm",
                              0.506 * DBH^1.021,
                              0.54 * DBH^1.021))

  # Calculate number of taps for each tree or dbh class
  Data$Taps <- with(Data,
                    ifelse(DBH >= taps3,
                           3,
                           ifelse(DBH >= taps2,
                                  2,
                                  1)))

  # Calculate total sap volume per tree - Morrow (1963)
  # 1 tap = model prediction
  # 2 taps = model prediction * 4/3 (i.e. 1.333)
  # 3 taps = model prediction * 4/3 * 1.2
  Data$Sap.tree <- with(Data, ifelse(Taps == 1,
                                     Sap.tap,
                                     ifelse(Taps == 2,
                                            Sap.tap * taps2.eff,
                                            ifelse(Taps == 3,
                                                   Sap.tap * taps2.eff * taps3.eff,
                                                   NA))))


  # Calculate total sap volume per DBH class
  # Note, if Freq = 1, Sap.tree = Sap.class
  Data$Sap.class <- with(Data, Sap.tree * Freq)


  # Calculate SSC for each tree
  Data$SSC <- with(Data, ifelse(Sp == "rm",
                                0.565 * DBH^0.3,
                                0.862 * DBH^0.3))

  # Calculate syrup yield per tree (Jones Rule)
  Data$Syrup.tree <- with(Data,
                          Sap.tree / (87.1/SSC - 0.32))

  # Calculate syrup yield per DBH class
  Data$Syrup.class <- with(Data, Syrup.tree * Freq)

  return(Data)
}


# Crown Class Routine
est.cc <- function(Data,
                   taps.over,
                   taps.int,
                   taps.codom,
                   taps.dom,
                   taps2.eff,
                   taps3.eff){

  # Estimated syrup equivalents by species/crown class
  const <- data.frame(Sp = c("rm","rm","rm","rm",
                             "sm","sm","sm","sm"),
                      CC = c("overtopped","intermediate","codominant","dominant",
                             "overtopped","intermediate","codominant","dominant"),
                      Syr.eq = c(0.04,0.06,0.13,0.17,
                              0.08,0.11,0.21,0.28),
                      Taps = c(taps.over, taps.int,
                               taps.codom, taps.dom,
                               taps.over, taps.int,
                               taps.codom, taps.dom))


  # Merge Data and const to get Syr.eq and number of taps
  # for each entry
  Data <- merge(Data, const, by = c("Sp","CC"), all.x = T)


  # Calculate Syrup per tree
  Data$Syrup.tree <- with(Data, ifelse(Taps == 1,
                                       Syr.eq,
                                       ifelse(Taps == 2,
                                              Syr.eq * taps2.eff,
                                              ifelse(Taps == 3,
                                                     Syr.eq * taps2.eff * taps3.eff,
                                                     NA))))


  # Calculate Syrup per class
  Data$Syrup.class <- with(Data, Syrup.tree * Freq)

  return(Data)

}


#' Estimate Maple Syrup Yield
#'
#' @description
#' Estimate potential sap and syrup production
#' of red maple (\emph{Acer rubrum}) and sugar
#' maple (\emph{Acer saccharum}) in southern forests
#' based on tree characteristics.
#'
#'
#' @param Data a data frame with columns 'Sp', 'DBH' (or 'CC'; see
#' user's guide), and 'Freq'. Data can take the form of a tree list (where each row is
#' represents a unique tree; in this case, Freq = 1) or a stand table (where each row
#' represents a unique combination of species and DBH/CC; Freq = number of trees
#' of this species and size class). Input DBH is in inches.
#' @param minDBH Numeric scalar identifying the minimum DBH of tree which will be tapped.
#' Estimated production of trees with DBH < minDBH will be set equal to 0. Default = 10 inches.
#' @param taps2 Numeric scalar identifying the DBH above which trees will receive 2 tree taps.
#' Default = 16 inches.
#' @param taps3 Numeric scalar identifying the DBH above which trees will receive 3 tree taps.
#' Default = 24 inches.
#' @param taps2.eff Numeric scalar identifying the increase in the efficiency of production
#' with 2 taps per tree relative to 1 tap. Default = 1.33 (Morrow 1963). Minimum value = 1.
#' @param taps3.eff Numeric scalar identifying the increase in the efficiency of production
#' with 3 taps per tree relative to 2 taps.Default = 1.2 (Morrow 1963). Minimum value = 1.
#' @param taps.over Numeric scalar identifying the number of taps used for trees in the
#' overtopped crown class. Default = 0 taps.
#' @param taps.int Numeric scalar identifying the number of taps used for trees in the
#' intermediate crown class. Default = 1 taps.
#' @param taps.codom Numeric scalar identifying the number of taps used for trees in the
#' codominant crown class. Default = 2 taps.
#' @param taps.dom Numeric scalar identifying the number of taps used for trees in the
#' dominant crown class. Default = 2 taps.
#'
#' @return A data frame with original input data and estimated production metrics by input record.
#' Summaries of total production metrics for all input trees are printed.
#'
#' @details See Supplement 3 of Hackworth et al. (in press) for the user's guide.
#'
#' @references Hackworth, Z.J., J.M. Lhotka, T.O. Ochuodho, and W.R. Thomas.
#' Informing producers in a non-traditional maple syrup region: Red maple and
#' sugar maple production parameters in Kentucky. In press.
#'
#' Morrow, R.R. 1963. Influence of number and depth of tap holes on
#' maple sap flow. Bulletin 982, Cornell University Agricultural Experiment Station,
#' Ithaca, NY, USA.
#'
#' @export
#'
#' @examples
#'
#' # DBH Example
#' boil(Data = uplands,
#'      taps2 = 16,
#'      taps3 = 24,
#'      minDBH = 10)
#'
#'
#' # Crown Class Example
#' boil(Data = uplands.cc,
#'      taps.over = 0,
#'      taps.int = 1,
#'      taps.codom = 2,
#'      taps.dom = 2)
#'
boil <- function(Data,
                 minDBH = 10,
                 taps2 = 16,
                 taps3 = 24,
                 taps2.eff = 1.33,
                 taps3.eff = 1.2,
                 taps.over = 0,
                 taps.int = 1,
                 taps.codom = 2,
                 taps.dom = 2){

  # Format data and data checks
  Data <- format.data(Data)

  # Estimation routines based on data input
  if("DBH" %in% colnames(Data)){
    Data <- est.dbh(Data,
                    taps2 = taps2,
                    taps3 = taps3,
                    taps2.eff = taps2.eff,
                    taps3.eff = taps3.eff)

    if(!is.na(minDBH)) Data[Data$DBH < minDBH, c(4:10)] <- 0
    if(any(Data$Freq == 0)) Data[Data$Freq == 0, c(4:10)] <- 0

  } else if("CC" %in% colnames(Data)){
    Data <- est.cc(Data,
                   taps2.eff = taps2.eff,
                   taps3.eff = taps3.eff,
                   taps.over = taps.over,
                   taps.int = taps.int,
                   taps.codom = taps.codom,
                   taps.dom = taps.dom)

    if(any(Data$Taps == 0 | Data$Freq == 0)) Data[Data$Taps == 0 | Data$Freq == 0, c(4:7)] <- 0

    } else stop("either DBH or CC must be specified")



  # Print total sap production of input table
  print(paste("Total estimated number of tappable trees =",
              sum(Data$Freq[Data$Taps>0])))
  print(paste("Total estimated number of taps =",
              sum(Data$Taps*Data$Freq)))
  print(paste("Total estimated maple syrup yield =",
              round(sum(Data$Syrup.class), 1),
              "gallons per year"))

  if("DBH" %in% colnames(Data)){
    print(paste("Average estimated sap sugar content =",
                round(sum(Data$SSC*Data$Sap.class/sum(Data$Sap.class)), 1),
                "\u00B0Brix"))
    print(paste("Average estimated sap yield per tap =",
                round(sum(Data$Sap.class) / sum((Data$Freq*Data$Taps)[Data$Taps>0]), 1),
                "gallons per year"))
  }
  return(Data)
}

#' @title Maple component of upland uneven-aged stand
#' @description Records of red and sugar maples from
#' stand table of upland uneven-aged stand.
#' @format A data frame with 30 rows and 3 variables:
#' \describe{
#'   \item{\code{Sp}}{character - tree species ("rm" = red maple; "sm" = sugar maple)}
#'   \item{\code{DBH}}{double - tree diameter at breast-height in inches}
#'   \item{\code{Freq}}{double - count of trees per acre presented by the row entry}
#'}
"uplands"

#' @title Maple component of upland uneven-aged stand specified with crown class
#' @description Records of red and sugar maples from
#' stand table of upland uneven-aged stand categorized by crown class.
#' @format A data frame with 30 rows and 3 variables:
#' \describe{
#'   \item{\code{Sp}}{character - tree species ("rm" = red maple; "sm" = sugar maple)}
#'   \item{\code{CC}}{double - tree crown class}
#'   \item{\code{Freq}}{double - count of trees per acre presented by the row entry}
#'}
"uplands.cc"
